
import java.io.ByteArrayInputStream
import java.io.PrintWriter
import java.io.StringWriter

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.hadoop.io.IOUtils
import org.apache.spark.launcher.SparkAppHandle
import org.apache.spark.launcher.SparkLauncher

import com.etl.scheduler.dao.SchedulerDAO
import com.util.MailUtil

import com.typesafe.config.ConfigFactory

import grizzled.slf4j.Logger

////change -guru start
import scala.collection.mutable.Queue
var q = new Queue[String]
q ++= List("Claims", "NetworkPricing","BenefitsClaim","MultipleFunctions","LineOverride","LevelOverride","HospitalClaims","HospitalConditionCode","ClaimCOBInformation","Diagnosis")
//change -guru end


/**
 *
 * Calls to this service are triggered by the Oracle Database Poller.
 *
 * This service does the following.
 * <a>Fetches the maximum last action datetime from the Hive table</a>
 * <b>Pass the maximum last action datetime to the Oracle SP to populate the ETL staging tables</b>
 * <c>Launches the Spark Jobs for  and Incremental</c>
 */

class SchedulerService {

  val logger = Logger[this.type]

  val HDFS_CONFIG = new Configuration

  
  
  def runETL(aInput: Any) {
    logger.info("******** Starting PING ETL Jobs ..**************")

    // Copy a trigger file to HDFS to launch the Job (45 tables) and Incremental (5 tables) load Job
    copyBytesToFile("Oracle DB refreshed", ConfigFactory.load.getString("oracle.status.file.path"))

    var start = System.currentTimeMillis
    
  try {
      val maxlastActionDteTime: String = SchedulerDAO.getMaxLastActionDate
      logger.info("Max Last ClaimAction Date " + maxlastActionDteTime + " retrieved in " + (System.currentTimeMillis - start))

      start = System.currentTimeMillis
      SchedulerDAO.loadStagingTables(maxlastActionDteTime, ConfigFactory.load.getInt("facets.oracledb.dop1"),
        ConfigFactory.load.getInt("facets.oracledb."), ConfigFactory.load.getInt("facets.oracledb.dop3"))
      logger.info("Staging tables loaded in " + (System.currentTimeMillis - start))
    } catch {
      case e: Exception => {
        logger.error(getStackTraceAsString(e))
        MailUtil.sendMail(s"ETLScheduler Error -> " + e.getMessage)
        throw new RuntimeException("runETL was terminated due to an Exception.")
      }
    }

    // Launch the  Load Job   
    
    //change -guru start
    if(!q.isEmpty){
    //change -guru end
    val sparkAppHandle = new SparkLauncher()
      .setSparkHome(ConfigFactory.load.getString("spark.home.location"))
      .setAppResource(ConfigFactory.load.getString("spark.resource.jar.location"))
    //change -guru start
      .addAppArgs(q.dequeue)
    //change -guru end
      .setMainClass("com.claims.PIDriver")
      .setMaster("yarn-cluster")
      .setConf("spark.executor.memory", ConfigFactory.load.getString("spark.conf.executor.memory."))
      .setConf("spark.executor.instances", ConfigFactory.load.getString("spark.conf.executor.instances."))
      .setConf("spark.executor.cores", ConfigFactory.load.getString("spark.conf.executor.cores."))
      .setConf("spark.yarn.queue", ConfigFactory.load.getString("spark.conf.queue."))
      .setConf("spark.driver.memory", ConfigFactory.load.getString("spark.conf.driver.memory."))
      .startApplication()
    }

    if(!q.isEmpty){

      //change-guru start     
      val sparkAppHandle = new SparkLauncher()
      .setSparkHome(ConfigFactory.load.getString("spark.home.location"))
      .setAppResource(ConfigFactory.load.getString("spark.resource.jar.location"))    
      .addAppArgs(q.dequeue)
      .setMainClass("com.claims.PIDriver")
      .setMaster("yarn-cluster")
      .setConf("spark.executor.memory", ConfigFactory.load.getString("spark.conf.executor.memory."))
      .setConf("spark.executor.instances", ConfigFactory.load.getString("spark.conf.executor.instances."))
      .setConf("spark.executor.cores", ConfigFactory.load.getString("spark.conf.executor.cores."))
      .setConf("spark.yarn.queue", ConfigFactory.load.getString("spark.conf.queue."))
      .setConf("spark.driver.memory", ConfigFactory.load.getString("spark.conf.driver.memory."))
      .startApplication()
      //change-guru end
    }

    sparkAppHandle.addListener(new SparkAppHandle.Listener() {
      @Override
      def stateChanged(handle: SparkAppHandle) = {
        // This method is called when the Application toggles between states (CONNECTED,SUBMITTED,RUNNING,FINISHED or FAILED or KILLED)
        val appState = handle.getState
        logger.info("stateChanged App ID " + handle.getAppId + ", State -> " + appState)

        if (appState.isFinal) {
          // Copy a trigger file to HDFS to launch the UBER Table load Job only if the App finished and did not fail or was not killed.
          if (appState == SparkAppHandle.State.FINISHED) {
//change-guru start     
if(!q.isEmpty){
      val sparkAppHandle = new SparkLauncher()
      .setSparkHome(ConfigFactory.load.getString("spark.home.location"))
      .setAppResource(ConfigFactory.load.getString("spark.resource.jar.location"))    
      .addAppArgs(q.dequeue)
      .setMainClass("com.claims.PIDriver")
      .setMaster("yarn-cluster")
      .setConf("spark.executor.memory", ConfigFactory.load.getString("spark.conf.executor.memory."))
      .setConf("spark.executor.instances", ConfigFactory.load.getString("spark.conf.executor.instances."))
      .setConf("spark.executor.cores", ConfigFactory.load.getString("spark.conf.executor.cores."))
      .setConf("spark.yarn.queue", ConfigFactory.load.getString("spark.conf.queue."))
      .setConf("spark.driver.memory", ConfigFactory.load.getString("spark.conf.driver.memory."))
      .startApplication()
      //change-guru end
    }

            //Compute Stats and Invalidate Metadata
            start = System.currentTimeMillis
            SchedulerDAO.updateTableMetadata
            logger.info("Hive and Impala metadata refreshed in " + (System.currentTimeMillis - start) + " seconds..so copying the _refresh.done file")
            copyBytesToFile(" ETL Spark Job and Metadata updates completed", ConfigFactory.load.getString(".status.file.path"))
            logger.info("**************  ETL Spark Job and Metadata updates were completed successfully... **************")
          } else if (appState == SparkAppHandle.State.KILLED || appState == SparkAppHandle.State.FAILED || appState == SparkAppHandle.State.UNKNOWN) {
            MailUtil.sendMail(s" Spark job did not complete, Application finished with status, " + appState)
            throw new RuntimeException(" Spark job did not complete, Application finished with status, " + appState)
          }
        }
      }

      @Override
      def infoChanged(handle: SparkAppHandle) = {
        // This method is called when the Application is assigned an ID after the Application is SUBMITTED 
        logger.info("infoChanged App ID " + handle.getAppId + ", State -> " + handle.getState)
      }
    });

  }

  def copyBytesToFile(aText: String, aHDFSPath: String) = {
    val dataops = FileSystem.get(HDFS_CONFIG).create(new Path(aHDFSPath), true)
    val byteips = new ByteArrayInputStream(aText.getBytes)
    IOUtils.copyBytes(byteips, dataops, HDFS_CONFIG)
  }

  def getStackTraceAsString(aThrowable: Throwable) = {
    val strWriter = new StringWriter
    aThrowable.printStackTrace(new PrintWriter(strWriter))
    strWriter.toString
  }
  
}